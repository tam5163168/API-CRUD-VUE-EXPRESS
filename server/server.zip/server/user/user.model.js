const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const User = new Schema({
    fullName: {
        type: String,
        min: 6,
        max: 255,
        required: true,
        default: 'Userspam'
    },
    email: {
        type: String,
        min: 6,
        max: 255,
        required: true,
    },
    password: {
        type: String,
        min: 4,
        max: 255,
        required: true,
    },
    active: {
        type: Number,
        default: 1,
    },
    role: {
        type: String,
        default: 'ACCOUNT'
    },
    createAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    },

});

module.exports = mongoose.model('User', User)