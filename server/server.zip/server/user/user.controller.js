const User = require('./user.model');

// Get
async function get(req, res) {
    try {
        const listUser = await User.find({});
        if (!listUser) throw new Error('User not found');
        res.status(200).json(listUser);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
}

// GetId
async function getID(req, res) {
    try {
        const user = await User.findById(req.params.userId);
        if (!user) throw new Error('Get userId not found');
        res.status(200).json({ status: 1, user });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
}



// Update
async function update(req, res) {
    try {
        const updatedUser = await User.updateOne({ _id: req.params.userId }, req.body);
        if (!updatedUser) throw new Error('updatedUser not found');
        res.status(200).json({ status: 1, updatedUser });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
}

// Delete
async function deleteUser(req, res) {
    try {
        if (!User.findOne({_id:req.params.userId})) throw new Error('Delete userId not found');
        const user = await User.deleteOne({ _id: req.params.userId });
        console.log(user);
        res.status(200).json({ status: 1, user });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
}

module.exports = { get, getID, update, deleteUser }