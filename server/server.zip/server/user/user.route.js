const express = require('express');
const router = express.Router();
const userController = require('./user.controller')
// Get all
router.get('/', userController.get)

// Get id
router.get('/:userId', userController.getID)

// Update
router.put('/:userId', userController.update)

// Delete 
router.delete('/:userId', userController.deleteUser)

module.exports = router
