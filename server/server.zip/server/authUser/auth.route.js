const express = require('express');
const router = express.Router();
const authValidation = require('../helpers/validation')
const authController = require('./auth.controller')

// login
router.get('/', authController.okNha)
router.post('/login', authValidation.login, authController.login)

// register 
router.post('/register', authValidation.register, authController.register)



module.exports = router
