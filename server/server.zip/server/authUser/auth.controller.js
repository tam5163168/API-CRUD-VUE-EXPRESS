const User = require('../user/user.model');
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
// Get
async function okNha(req, res) {
    let token = req.headers.token
    console.log(token);
    try {
        const decoded = jwt.verify(token, process.env.TOKEN_SECRET);
        const user = await User.findOne({_id: decoded._id});
        res.status(200).json({title: 'user', user: { email: user.email, name: user.fullName}});
    } catch (error) {
        res.status(401).send(error.message);
    }
}

async function login(req, res) {
    try {
        const userEmail = await User.findOne({email: req.body.email})
        if (!userEmail) return res.status(400).send({email: 'Email not found'})
        // Password is correct
        const password = await bcrypt.compare(req.body.password, userEmail.password)
        if (!password) return res.status(400).send({password: 'Password incorrect'})

        // Create and assign a token
        
        const token = jwt.sign({ _id: userEmail._id }, process.env.TOKEN_SECRET, { expiresIn: 60 * 60 })
        res.status(200).send({email: userEmail.email, token: token})
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
}

// Create
async function register(req, res) {
    const emailExist = await User.findOne({ email: req.body.email })
    if(emailExist) return res.status(400).send({message: 'Email already'})

    // Hash Password
    const salt = await bcrypt.genSalt(10);
    const hashPassword = await bcrypt.hash(req.body.password, salt)
    const createUser = new User({
        fullName: req.body.fullName,
        email: req.body.email,
        password: hashPassword,
    });
    try {
        if (!createUser) throw new Error('Create User not found')
        const postUser = await createUser.save();
        if (!postUser) throw new Error('Post user failed')
        res.status(200).json({ status: 1, postUser });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
}

module.exports = { login, register, okNha}